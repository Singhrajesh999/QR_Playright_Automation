/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
  "stage": {
    "version": "6.0.0",
    "minimumCompatibleVersion": "5.0.0",
    "build": "6.0.0.400",
    "scaleToFit": "none",
    "centerStage": "none",
    "resizeInstances": false,
    "content": {
      "dom": [
        {
          "id": "Rectangle1",
          "type": "rect",
          "rect": [
            "0px",
            "0px",
            "728px",
            "90px",
            "auto",
            "auto"
          ],
          "fill": [
            "rgba(99,128,36,1.00)"
          ],
          "stroke": [
            0,
            "rgba(0,0,0,1)",
            "none"
          ]
        },
        {
          "id": "w2img_1_1_2_Pic1",
          "type": "image",
          "rect": [
            "0",
            "-1",
            "190px",
            "90px",
            "auto",
            "auto"
          ],
          "opacity": "0",
          "fill": [
            "rgba(0,0,0,0)",
            "images/Pic1.jpg",
            "0px",
            "0px"
          ]
        },
        {
          "id": "Rectangle2",
          "type": "rect",
          "rect": [
            "184px",
            "0px",
            "543px",
            "90px",
            "auto",
            "auto"
          ],
          "borderRadius": [
            "16px 16px",
            "0px",
            "16px 16px",
            "0px"
          ],
          "opacity": "0",
          "fill": [
            "rgba(245,243,219,1.00)"
          ],
          "stroke": [
            0,
            "rgb(0, 0, 0)",
            "none"
          ]
        },
        {
          "id": "w2img_1_1_1_Logo",
          "type": "image",
          "rect": [
            "187px",
            "15px",
            "97px",
            "57px",
            "auto",
            "auto"
          ],
          "opacity": "0",
          "fill": [
            "rgba(0,0,0,0)",
            "images/Logo.png",
            "0px",
            "0px"
          ]
        },
        {
          "id": "w2txt_1_1_1_Heading",
          "type": "text",
          "rect": [
            "293px",
            "28px",
            "416px",
            "45px",
            "auto",
            "auto"
          ],
          "opacity": "0",
          "text": "\u003cp style\u003d\"margin:0px\"\u003eAGRICULTURAL SALE​\u003c/p\u003e",
          "align": "center",
          "font": [
            "Georgia, Times New Roman, Times, serif",
            [
              30,
              "px"
            ],
            "rgba(0,0,0,1)",
            "700",
            "none",
            "",
            "break-word",
            "normal"
          ],
          "textStyle": [
            "",
            "",
            "36px",
            "",
            ""
          ]
        },
        {
          "id": "w2txt_1_1_2_SubHeading",
          "type": "text",
          "rect": [
            "295px",
            "12px",
            "410px",
            "43px",
            "auto",
            "auto"
          ],
          "opacity": "0",
          "text": "\u003cp style\u003d\"margin:0px\"\u003eAgricultural Fertilizer Products​\u003c/p\u003e",
          "align": "center",
          "font": [
            "Arial, Helvetica, sans-serif",
            [
              25,
              "px"
            ],
            "rgba(0,0,0,1)",
            "700",
            "none solid rgb(0, 0, 0)",
            "normal",
            "break-word",
            "normal"
          ],
          "textStyle": [
            "",
            "",
            "30px",
            "",
            ""
          ]
        },
        {
          "id": "Rectangle",
          "type": "rect",
          "rect": [
            "449px",
            "90px",
            "100px",
            "25px",
            "auto",
            "auto"
          ],
          "borderRadius": [
            "4px",
            "4px",
            "4px",
            "4px 4px"
          ],
          "opacity": "0",
          "fill": [
            "rgba(120,156,63,1.00)"
          ],
          "stroke": [
            0,
            "rgb(0, 0, 0)",
            "none"
          ]
        },
        {
          "id": "w2txt_1_1_3_CallToAction",
          "type": "text",
          "rect": [
            "449px",
            "90px",
            "99px",
            "25px",
            "auto",
            "auto"
          ],
          "opacity": "0",
          "text": "\u003cp style\u003d\"margin:0px\"\u003eKnow More\u003c/p\u003e",
          "align": "center",
          "font": [
            "Arial, Helvetica, sans-serif",
            [
              15,
              "px"
            ],
            "rgba(255,255,255,1.00)",
            "400",
            "none solid rgb(0, 0, 0)",
            "normal",
            "break-word",
            "normal"
          ],
          "textStyle": [
            "",
            "",
            "25px",
            "",
            ""
          ]
        },
        {
          "id": "w2txt_1_1_4_clickthru",
          "type": "text",
          "rect": [
            "54px",
            "15px",
            "279px",
            "67px",
            "auto",
            "auto"
          ],
          "opacity": "0",
          "text": "http://www.wav2.com",
          "font": [
            "Arial, Helvetica, sans-serif",
            [
              12,
              "px"
            ],
            "rgba(0,0,0,1)",
            "normal",
            "none",
            "",
            "break-word",
            "normal"
          ]
        },
        {
          "id": "Border",
          "type": "rect",
          "rect": [
            "0px",
            "0px",
            "726px",
            "88px",
            "auto",
            "auto"
          ],
          "fill": [
            "rgba(192,183,92,0.00)"
          ],
          "stroke": [
            1,
            "rgb(0, 0, 0)",
            "solid"
          ]
        },
        {
          "id": "Button",
          "type": "rect",
          "rect": [
            "0px",
            "0px",
            "728px",
            "90px",
            "auto",
            "auto"
          ],
          "cursor": "pointer",
          "opacity": "0",
          "fill": [
            "rgba(192,192,192,1)"
          ],
          "stroke": [
            0,
            "rgba(0,0,0,1)",
            "none"
          ]
        }
      ],
      "style": {
        "${Stage}": {
          "isStage": true,
          "rect": [
            "null",
            "null",
            "728px",
            "90px",
            "auto",
            "auto"
          ],
          "overflow": "hidden",
          "fill": [
            "rgba(255,255,255,1)"
          ]
        }
      }
    },
    "timeline": {
      "duration": 6500,
      "autoPlay": true,
      "data": [
        [
          "eid14",
          "opacity",
          0,
          500,
          "linear",
          "${w2img_1_1_2_Pic1}",
          "0.000000",
          "1"
        ],
        [
          "eid58",
          "opacity",
          5930,
          570,
          "linear",
          "${Rectangle}",
          "0",
          "1"
        ],
        [
          "eid61",
          "top",
          5930,
          570,
          "linear",
          "${w2txt_1_1_3_CallToAction}",
          "90px",
          "58px"
        ],
        [
          "eid49",
          "top",
          5930,
          570,
          "linear",
          "${w2txt_1_1_2_SubHeading}",
          "24px",
          "12px"
        ],
        [
          "eid13",
          "opacity",
          750,
          500,
          "linear",
          "${w2img_1_1_1_Logo}",
          "0.000000",
          "1"
        ],
        [
          "eid59",
          "opacity",
          5930,
          570,
          "linear",
          "${w2txt_1_1_3_CallToAction}",
          "0",
          "1"
        ],
        [
          "eid60",
          "top",
          5930,
          570,
          "linear",
          "${Rectangle}",
          "90px",
          "58px"
        ],
        [
          "eid16",
          "opacity",
          0,
          500,
          "linear",
          "${Rectangle2}",
          "0.000000",
          "1"
        ],
        [
          "eid17",
          "opacity",
          1430,
          500,
          "linear",
          "${w2txt_1_1_1_Heading}",
          "0.000000",
          "1"
        ],
        [
          "eid46",
          "opacity",
          4250,
          575,
          "linear",
          "${w2txt_1_1_1_Heading}",
          "1",
          "0"
        ],
        [
          "eid15",
          "opacity",
          4825,
          500,
          "linear",
          "${w2txt_1_1_2_SubHeading}",
          "0.000000",
          "1"
        ]
      ]
    }
  }
};

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("Agriculture2%20728%20x%2090_edgeActions.js");
})("EDGE-27885125");
